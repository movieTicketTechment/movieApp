package com.techment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.techment.dto.UserDto;
import com.techment.entity.User;
import com.techment.service.IUserService;

@CrossOrigin
@RestController
@RequestMapping(value = "/movieTicketBooking")
public class UserController {
	
	@Autowired
	IUserService iUserService;
	
	
	@GetMapping(value = "/viewAllMovies")
	public List<UserDto> viewAllUser(){
		return iUserService.viewAllUser();
	}
	

	@PostMapping(value ="/addNewUser")
	public ResponseEntity<String> addNewUser(@RequestBody UserDto userDto)
			{
		return new ResponseEntity<String>(iUserService.addUser(userDto), HttpStatus.ACCEPTED);
			}
	
	
	@GetMapping(value = "/viewUserById/{id}")
	public UserDto getUserById(@PathVariable int id)
	{	
			return iUserService.viewUserById(id);
		
	}
	
	@GetMapping(value = "/login/{userName}/{userPassword}")
	public ResponseEntity<String> login(@PathVariable String userName, @PathVariable String userPassword)
	{
		UserDto users = iUserService.logined(userName, userPassword);
		
		if(users!=null) {
			
			return new ResponseEntity<String>("Login SuccessFull "+users.getRole(), HttpStatus.ACCEPTED);
		}
		else {
			return new ResponseEntity<String>("Wrong Entries", HttpStatus.ALREADY_REPORTED);
		}
	}
	
	@DeleteMapping("/deleteUser/{id}")  
	private void delete(@PathVariable("id") int id)   
	{ 
	
	iUserService.deleteById(id);  
		
	}
	
	@PutMapping(value="/updateValues/{id}")
	public ResponseEntity<String> update(@PathVariable int id, @RequestBody UserDto userDto)
	{	
        iUserService.gets(id);
		
		UserDto users = userDto;
		users.setUserId(id);
	
		iUserService.addUser(users);
		
		return new ResponseEntity<String>("user updated..",HttpStatus.OK);
		
	}


}
