package com.techment.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.techment.dto.TicketBookingDto;
import com.techment.dto.UserDto;
import com.techment.entity.TicketBooking;
import com.techment.entity.User;
import com.techment.service.ITicketBookingService;

@CrossOrigin
@RestController
@RequestMapping(value = "/ticketBooking")
public class TicketBookingController {
	 
	ITicketBookingService iTicketBookingService;
	
	@GetMapping(value = "/viewAllTicketBooing")
	public List<TicketBookingDto> viewAllTicketBooing(){
		
		return iTicketBookingService.viewAllTicketBooking();
	}	
	
	@PostMapping(value ="/addNewTicketBooking")
	public ResponseEntity<String> addNewUser(@RequestBody TicketBookingDto ticketBookingDto)
			{
		return new ResponseEntity<String>(iTicketBookingService.addTicketBooking(ticketBookingDto), HttpStatus.ACCEPTED);
			}
//	
//	@GetMapping(value = "/viewTicketBookingById/{id}")
//	public TicketBookingDto getUserById(@PathVariable int id)
//	{	
//			return iTicketBookingService.viewTicketBookingById(id);
//		
//	}
//	
//	
//	
//	@DeleteMapping("/deleteUser/{id}")  
//	private void delete(@PathVariable("id") int id)   
//	{ 
//	
//	iTicketBookingService.deleteById(id);  
//		
//	}
//	
//	@PutMapping(value="/updateValues/{id}")
//	public ResponseEntity<String> update(@PathVariable int id, @RequestBody TicketBookingDto ticketBookingDto)
//	{	
//		iTicketBookingService.gets(id);
//		
//		TicketBookingDto ticketBooking = ticketBookingDto;
//		ticketBooking.setTicketId(id);
//	
//		iTicketBookingService.addTicketBooking(ticketBooking);
//		
//		return new ResponseEntity<String>("user updated..",HttpStatus.OK);
//		
//	}
//

}

	
	

