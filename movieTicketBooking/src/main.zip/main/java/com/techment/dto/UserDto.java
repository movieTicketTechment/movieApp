package com.techment.dto;

public class UserDto {

	
	
	private int userId;
	private String userName;
	private String userPassword;
	private String userAddress;
	private String userEmail;
	private String userMobile;
	private String role;
	private String updatedBy;
	private String updatedOn;
	private String resetPassword;
	private String loginValidUpto;
	private String loginfailCount;
	private String loginSuspendUpto;
	private String loginOtp;
	private String deletedFile;
	private String status;
	private String remark;
	private String token;
	
	
	public UserDto() {
		super();
	}


	public UserDto(int userId, String userName, String userPassword, String userAddress, String userEmail,
			String userMobile, String role, String updatedBy, String updatedOn, String resetPassword,
			String loginValidUpto, String loginfailCount, String loginSuspendUpto, String loginOtp, String deletedFile,
			String status, String remark, String token) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userAddress = userAddress;
		this.userEmail = userEmail;
		this.userMobile = userMobile;
		this.role = role;
		this.updatedBy = updatedBy;
		this.updatedOn = updatedOn;
		this.resetPassword = resetPassword;
		this.loginValidUpto = loginValidUpto;
		this.loginfailCount = loginfailCount;
		this.loginSuspendUpto = loginSuspendUpto;
		this.loginOtp = loginOtp;
		this.deletedFile = deletedFile;
		this.status = status;
		this.remark = remark;
		this.token = token;
	}


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getUserPassword() {
		return userPassword;
	}


	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}


	public String getUserAddress() {
		return userAddress;
	}


	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}


	public String getUserEmail() {
		return userEmail;
	}


	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}


	public String getUserMobile() {
		return userMobile;
	}


	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public String getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}


	public String getUpdatedOn() {
		return updatedOn;
	}


	public void setUpdatedOn(String updatedOn) {
		this.updatedOn = updatedOn;
	}


	public String getResetPassword() {
		return resetPassword;
	}


	public void setResetPassword(String resetPassword) {
		this.resetPassword = resetPassword;
	}


	public String getLoginValidUpto() {
		return loginValidUpto;
	}


	public void setLoginValidUpto(String loginValidUpto) {
		this.loginValidUpto = loginValidUpto;
	}


	public String getLoginfailCount() {
		return loginfailCount;
	}


	public void setLoginfailCount(String loginfailCount) {
		this.loginfailCount = loginfailCount;
	}


	public String getLoginSuspendUpto() {
		return loginSuspendUpto;
	}


	public void setLoginSuspendUpto(String loginSuspendUpto) {
		this.loginSuspendUpto = loginSuspendUpto;
	}


	public String getLoginOtp() {
		return loginOtp;
	}


	public void setLoginOtp(String loginOtp) {
		this.loginOtp = loginOtp;
	}


	public String getDeletedFile() {
		return deletedFile;
	}


	public void setDeletedFile(String deletedFile) {
		this.deletedFile = deletedFile;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getRemark() {
		return remark;
	}


	public void setRemark(String remark) {
		this.remark = remark;
	}


	public String getToken() {
		return token;
	}


	public void setToken(String token) {
		this.token = token;
	}


	@Override
	public String toString() {
		return "UserDto [userId=" + userId + ", userName=" + userName + ", userPassword=" + userPassword
				+ ", userAddress=" + userAddress + ", userEmail=" + userEmail + ", userMobile=" + userMobile + ", role="
				+ role + ", updatedBy=" + updatedBy + ", updatedOn=" + updatedOn + ", resetPassword=" + resetPassword
				+ ", loginValidUpto=" + loginValidUpto + ", loginfailCount=" + loginfailCount + ", loginSuspendUpto="
				+ loginSuspendUpto + ", loginOtp=" + loginOtp + ", deletedFile=" + deletedFile + ", status=" + status
				+ ", remark=" + remark + ", token=" + token + "]";
	}
	
	
	
	
	
}
