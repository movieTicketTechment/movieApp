package com.techment.entity;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name= "screen")
public class Screen {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private  int screenId;
	private  String screenName;
	private  int screenRows;
	private  int screenColumns;
	private  String updatedBy;
	private  LocalDateTime updatedOn;
	private  String deleteField;
	private  String status;
	private  String remark;
	private  String token;
	
    @ManyToOne  
    private Theatre theatre;  
	
	

	public Screen() {
		super();
	}



	public Screen(int screenId, String screenName, int screenRows, int screenColumns, String updatedBy,
			LocalDateTime updatedOn, String deleteField, String status, String remark, String token, Theatre theatre) {
		super();
		this.screenId = screenId;
		this.screenName = screenName;
		this.screenRows = screenRows;
		this.screenColumns = screenColumns;
		this.updatedBy = updatedBy;
		this.updatedOn = updatedOn;
		this.deleteField = deleteField;
		this.status = status;
		this.remark = remark;
		this.token = token;
		this.theatre = theatre;
	}



	public int getScreenId() {
		return screenId;
	}



	public void setScreenId(int screenId) {
		this.screenId = screenId;
	}



	public String getScreenName() {
		return screenName;
	}



	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}



	public int getScreenRows() {
		return screenRows;
	}



	public void setScreenRows(int screenRows) {
		this.screenRows = screenRows;
	}



	public int getScreenColumns() {
		return screenColumns;
	}



	public void setScreenColumns(int screenColumns) {
		this.screenColumns = screenColumns;
	}



	public String getUpdatedBy() {
		return updatedBy;
	}



	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}



	public LocalDateTime getUpdatedOn() {
		return updatedOn;
	}



	public void setUpdatedOn(LocalDateTime updatedOn) {
		this.updatedOn = updatedOn;
	}



	public String getDeleteField() {
		return deleteField;
	}



	public void setDeleteField(String deleteField) {
		this.deleteField = deleteField;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public String getRemark() {
		return remark;
	}



	public void setRemark(String remark) {
		this.remark = remark;
	}



	public String getToken() {
		return token;
	}



	public void setToken(String token) {
		this.token = token;
	}



	public Theatre getTheatre() {
		return theatre;
	}



	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	}
	

}
