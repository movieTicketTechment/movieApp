package com.techment.service;

import java.util.List;

import com.techment.dto.ShowDto;
import com.techment.entity.Show;


public interface IShowService {

	List<ShowDto> viewAllShow();
   String addShow(ShowDto showDto);
	
   /*ShowDto viewShowById(int id);
	Show gets(int id);*/
	void deleteShowById(int id);
	
}
