package com.techment.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.techment.dto.TicketBookingDto;
import com.techment.dto.UserDto;
import com.techment.entity.TicketBooking;
import com.techment.entity.User;
import com.techment.repository.ITicketBookingRepository;

@Service
public class TicketBookingServiceImpl implements ITicketBookingService {

	
	@Autowired
	ITicketBookingRepository ticketBookingRepo;
	
	@Override
	public List<TicketBookingDto> viewAllTicketBooking() {
		// TODO Auto-generated method stub
		List<TicketBooking> ticketBooking = ticketBookingRepo.findAll();
		
		List<TicketBookingDto> ticketBookingDto = new ArrayList<TicketBookingDto>();
		
		for(TicketBooking t : ticketBooking)
		{
			ticketBookingDto.add(new TicketBookingDto(t.getBookingId(),t.getBookingDate(),t.getTotalPrice(),t.getBookingRef(),t.getLockTime(),t.getUserIpAdd(),t.getBookingStatus(),t.getUpdatedBy(),t.getUpdatedOn(),t.getDeleteField(),t.getStatus(),t.getRemark(),t.getToken(),t.getPaymentId(),t.getShowId(),t.getSeatIds(),t.getVals(),t.getUser()));
		
		}

		return ticketBookingDto;	
	}

	@Override
	public String addTicketBooking(TicketBookingDto ticketBookingDto) {
		TicketBooking ticketBooking = new TicketBooking();
		if(ticketBookingDto.getBookingId()!=0)
		{
			ticketBooking.setBookingId(ticketBookingDto.getBookingId());
			ticketBooking.setShowId(ticketBookingDto.getShowId());
			ticketBooking.setBookingDate(ticketBookingDto.getBookingDate());
			ticketBooking.setBookingStatus(ticketBookingDto.getBookingStatus());
			ticketBooking.setPaymentId(ticketBookingDto.getPaymentId());
			ticketBooking.setBookingRef(ticketBookingDto.getBookingRef());
			ticketBooking.setTotalPrice(ticketBookingDto.getTotalPrice());
			ticketBookingRepo.save(ticketBooking);
	     	return "Ticket Booking Added";
		}
		
		return null;
	}

//	@Override
//	public String addTicketBooking(TicketBookingDto ticketBookingDto) {
//
//		TicketBooking ticketBooking = new TicketBooking();
//		if(ticketBookingDto.getTicketId()!=0)
//		{
//			ticketBooking.setTicketId(ticketBookingDto.getTicketId());
//		}
//		ticketBooking.setShowId(ticketBookingDto.getShowId());
//		ticketBooking.setBookingDate(ticketBookingDto.getBookingDate());
//		ticketBooking.setTransactionId(ticketBookingDto.getTransactionId());
//		ticketBooking.setTransactionMode(ticketBookingDto.getTransactionMode());
//		ticketBooking.setTransactionStatus(ticketBookingDto.getTransactionStatus());
//		ticketBooking.setTotalCost(ticketBookingDto.getTotalCost());
//		ticketBookingRepo.save(ticketBooking);
//		return "Ticket Booking Added";
//	}
//
//	@Override
//	public TicketBookingDto viewTicketBookingById(int id) {
//		// TODO Auto-generated method stub
//		
//		TicketBooking ticketBooking = ticketBookingRepo.findById(id).get();
//		TicketBookingDto ticketBookingDto = new TicketBookingDto(ticketBooking.getTicketId(),ticketBooking.getShowId(),ticketBooking.getBookingDate(),ticketBooking.getTransactionId(),ticketBooking.getTransactionMode(),ticketBooking.getTransactionStatus(),ticketBooking.getTotalCost());
//		
//		return ticketBookingDto;
//	}
//
//	@Override
//	public void deleteById(int id) {
//		// TODO Auto-generated method stub
//		ticketBookingRepo.deleteById(id);
//	}
//
//	@Override
//	public TicketBooking gets(int id) {
//		// TODO Auto-generated method stub
//		return ticketBookingRepo.findById(id).get();
//	}
//	

}
