package com.techment.service;

import java.util.List;

import com.techment.dto.TicketBookingDto;
import com.techment.entity.TicketBooking;

public interface ITicketBookingService {

	List<TicketBookingDto> viewAllTicketBooking();
	
	String addTicketBooking(TicketBookingDto tickBookingDto);
//	
//	TicketBookingDto viewTicketBookingById(int id);
//	
//	void deleteById(int id);
//	
//	TicketBooking gets(int id);
//	
}
