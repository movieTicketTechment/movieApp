package com.techment.entity;


import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name= "showDetail")
public class Show  {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private  int showId;
	private   LocalDateTime showStartTime;
	private  LocalDateTime showEndTime;
	private  String showName;	
	private  String updatedBy;
	private  LocalDateTime updatedOn;	
	private  String deleteField;
	private  String status;
	private  String remark;
	private  String token;
	@ManyToOne
	@JoinColumn(name="movieId", referencedColumnName = "movieId")
	private  Movie movie;
	@ManyToOne
	@JoinColumn(name="theatred", referencedColumnName = "theatreId")
	private  Theatre theatre;
	@ManyToOne
	@JoinColumn(name="screenId", referencedColumnName = "screenId")
	private  Screen screen;


	public Show() {
		super();
	}


	public Show(int showId, LocalDateTime showStartTime, LocalDateTime showEndTime, String showName, String updatedBy,
			LocalDateTime updatedOn, String deleteField, String status, String remark, String token, Movie movie,
			Theatre theatre, Screen screen) {
		super();
		this.showId = showId;
		this.showStartTime = showStartTime;
		this.showEndTime = showEndTime;
		this.showName = showName;
		this.updatedBy = updatedBy;
		this.updatedOn = updatedOn;
		this.deleteField = deleteField;
		this.status = status;
		this.remark = remark;
		this.token = token;
		this.movie = movie;
		this.theatre = theatre;
		this.screen = screen;
	}


	public int getShowId() {
		return showId;
	}


	public void setShowId(int showId) {
		this.showId = showId;
	}


	public LocalDateTime getShowStartTime() {
		return showStartTime;
	}


	public void setShowStartTime(LocalDateTime showStartTime) {
		this.showStartTime = showStartTime;
	}


	public LocalDateTime getShowEndTime() {
		return showEndTime;
	}


	public void setShowEndTime(LocalDateTime showEndTime) {
		this.showEndTime = showEndTime;
	}


	public String getShowName() {
		return showName;
	}


	public void setShowName(String showName) {
		this.showName = showName;
	}


	public String getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}


	public LocalDateTime getUpdatedOn() {
		return updatedOn;
	}


	public void setUpdatedOn(LocalDateTime updatedOn) {
		this.updatedOn = updatedOn;
	}


	public String getDeleteField() {
		return deleteField;
	}


	public void setDeleteField(String deleteField) {
		this.deleteField = deleteField;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getRemark() {
		return remark;
	}


	public void setRemark(String remark) {
		this.remark = remark;
	}


	public String getToken() {
		return token;
	}


	public void setToken(String token) {
		this.token = token;
	}


	public Movie getMovie() {
		return movie;
	}


	public void setMovie(Movie movie) {
		this.movie = movie;
	}


	public Theatre getTheatre() {
		return theatre;
	}


	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	}


	public Screen getScreen() {
		return screen;
	}


	public void setScreen(Screen screen) {
		this.screen = screen;
	}


	
	
	}
