package com.techment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.techment.entity.Show;

public interface IShowRepository extends JpaRepository<Show, Integer> {

}
