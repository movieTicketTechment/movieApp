package com.techment.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.techment.dto.UserDto;
import com.techment.entity.User;
import com.techment.repository.IUserRepository;

@Service
public class UserServiceImpl implements IUserService{

	
	@Autowired
	IUserRepository userRepo;

	@Override
	public List<UserDto> viewAllUser() {
		
    List<User> users =	userRepo.findAll();
		
		List<UserDto> userDto = new ArrayList<UserDto>();
		
		for(User u : users)
		{
			userDto.add(new UserDto(u.getUserId(), u.getUserName(),u.getUserPassword(),u.getUserAddress(),u.getUserEmail(),u.getUserMobile(),u.getRole(),u.getUpdatedBy(),u.getUpdatedOn(),u.getResetPassword(),u.getLoginValidUpto(),u.getLoginfailCount(),u.getLoginSuspendUpto(),u.getLoginOtp(),u.getDeletedFile(),u.getStatus(),u.getRemark(),u.getToken()));
		}
		
		
		return userDto;
		
	}
	
	
	@Override
	public String addUser(UserDto userDto) {
	
		User user = new User();
		if(userDto.getUserId()!=0)
		{
			user.setUserId(userDto.getUserId());
		}
		user.setUserName(userDto.getUserName());
		user.setUserAddress(userDto.getUserAddress());
		user.setUserPassword(userDto.getUserPassword());
		user.setUserEmail(userDto.getUserEmail());
		user.setUserMobile(userDto.getUserMobile());
		userRepo.save(user);
		return "User Added";
	}


	@Override
	public UserDto viewUserById(int id) {
		User user = userRepo.findById(id).get();
		UserDto userDto = new UserDto(user.getUserId(), user.getUserName(),user.getUserPassword(),user.getUserAddress(),user.getUserEmail(),user.getUserMobile(),user.getRole(),user.getUpdatedBy(),user.getUpdatedOn(),user.getResetPassword(),user.getLoginValidUpto(),user.getLoginfailCount(),user.getLoginSuspendUpto(),user.getLoginOtp(),user.getDeletedFile(),user.getStatus(),user.getRemark(),user.getToken());
		return userDto;
	}


	@Override
	public void deleteById(int id) {
		userRepo.deleteById(id);
		
	}

	@Override
	public User gets(int id) {
		
		return userRepo.findById(id).get();
	}


	@Override
	public UserDto logined(String userName, String userPassword) {

		
		User user = userRepo.findByUserNameAndUserPassword(userName, userPassword).get();
		
		UserDto userDto= new UserDto(user.getUserId(), user.getUserName(),user.getUserPassword(),user.getUserAddress(),user.getUserEmail(),user.getUserMobile(),user.getRole(),user.getUpdatedBy(),user.getUpdatedOn(),user.getResetPassword(),user.getLoginValidUpto(),user.getLoginfailCount(),user.getLoginSuspendUpto(),user.getLoginOtp(),user.getDeletedFile(),user.getStatus(),user.getRemark(),user.getToken()) ;
		return userDto;
		
	}
	
	
}
